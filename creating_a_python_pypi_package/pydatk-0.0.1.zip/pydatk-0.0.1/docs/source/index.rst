.. pydatk documentation master file, created by
   sphinx-quickstart on Sat Jun  7 20:04:41 2025.

pydatk
======

Welcome to the pydatk documentation.

.. toctree::
   :maxdepth: 3
   :caption: Contents:
   
   modules   

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`