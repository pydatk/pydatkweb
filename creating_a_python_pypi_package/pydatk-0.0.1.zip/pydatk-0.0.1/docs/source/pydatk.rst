pydatk package
==============

Submodules
----------

pydatk.finance module
---------------------

.. automodule:: pydatk.finance
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pydatk
   :members:
   :show-inheritance:
   :undoc-members:
